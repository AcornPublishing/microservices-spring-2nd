package se.magnus.microservices.composite.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCompositeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
